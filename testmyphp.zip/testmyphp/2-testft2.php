<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing php Function</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php 
    /*Defining a PHP Function */
    function addFunction($num1,$num2): void{
        $sum = $num1 + $num2;
        echo "Sum of hte two numbers is : $sum";
    }
    /* Calling a PHP Function */
    addFunction(10, 20);
    ?>
</body>
</html>