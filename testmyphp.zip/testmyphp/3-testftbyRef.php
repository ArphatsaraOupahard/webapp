<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Referance</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php 
    /*Defining a PHP add addFive Function */
    function addFive($num): void{
        $num += 5;
    }
    /*Defining a PHP add addSix Function */
    /*add & it addSix Function */
    function addSix(&$num) {
        $num +=6;
    }

    $orignum = 10;
    addFive($orignum);

    echo "Original Value is $orignum<br />";
    
    addSix($orignum);
    echo "Original Value is $orignum<br />";
    ?>
</body>
</html>