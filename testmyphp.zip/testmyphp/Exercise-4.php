<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Referance</title>
</head>
<body>
    <h2>E4</h2>
    <?php 
    /*Defining a PHP add addFive Function */
    function test($s) {
        $ctr_aa = 0;
        for ($i = 0; $i < strlen($s) - 1; $i++) {
            if (substr($s, $i, 2) == "aa") {
                $ctr_aa++;
            }
        } 
        return $ctr_aa;
        
    }
    echo test("bbaaccaag"). "<br/>\n";
    echo test("jjkiaaasew"). "<br/>\n";
    echo test("JSaaakoiaa"). "\n";
    
    ?>
</body>
</html>