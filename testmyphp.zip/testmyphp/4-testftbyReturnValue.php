<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Referance</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php 
    /*Defining a PHP add addFive Function */
    function addFunctioon($num1, $num2) {
        $sum = $num1 + $num2;
        return $sum;
    }
    $return_value = addFunctioon(10, 20);

    echo "Returned value from the function : $return_value";
    ?>
</body>
</html>