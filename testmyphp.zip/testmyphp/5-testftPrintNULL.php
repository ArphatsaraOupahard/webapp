<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Referance</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php 
    /*Defining a PHP add addFive Function */
    function printMe($param = NULL) {
        print $param;
    }
    printMe("This is test");
    printMe();
    printMe("<br />This is test");
    printMe();
    ?>
</body>
</html>