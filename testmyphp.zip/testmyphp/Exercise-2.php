<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Referance</title>
</head>
<body>
    <h2>E2</h2>
    <?php 
    /*Defining a PHP add addFive Function */
    function test($temp1, $temp2) {
    return $temp1 < 0 && $temp2 > 100 || $temp2 < 0 && $temp1 >100;
    }
        var_dump(test(120, -1)); echo "<br/>";
        var_dump(test(-1, 120));echo "<br/>";
        var_dump(test(2, 120));echo "<br/>";
    
    ?>
</body>
</html>